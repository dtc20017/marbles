# Drop your keys/certs in this folder.

## Private Key:
- name the file `privateKey.pem`
- Contents should include `-----BEGIN PRIVATE KEY-----` and `-----END PRIVATE KEY-----`

## Certificate: 
- name the file `signedCert.pem`
- Contents should include `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----`
